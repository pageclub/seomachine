# SEO Machine — Drop-In Files

These files add Entity SEO support and local page generation to the base pageclub/seomachine repo.

---

## What's Included

### New Context Files (`context/`)

| File | Purpose |
|---|---|
| `entity-seo.md` | Full Entity SEO framework with 9 entity categories, template, checklist, and schema rules |
| `seo-guidelines.md` | Replaces the blank template — includes entity SEO requirements, content length standards, schema rules |
| `brand-voice.md` | Fill this in with your business info before running any commands |
| `target-keywords.md` | Fill this in with your service/city keyword combinations |
| `internal-links-map.md` | Fill this in with your existing pages for internal linking |
| `style-guide.md` | Editorial standards for tone, formatting, grammar |
| `competitor-analysis.md` | Fill this in with competitor intel and gaps |
| `writing-examples.md` | Paste 2–3 of your best pages here so Claude can match your voice |

### New Commands (`.claude/commands/`)

| Command | What It Does |
|---|---|
| `/local-page` | Generates a full Service + City landing page with entity map, entity density check, and schema |
| `/write` | Updated version with entity SEO awareness baked in |

### Empty Working Directories

- `topics/` — drop raw topic ideas here
- `research/` — research briefs saved here by `/research`
- `drafts/` — blog post drafts saved here by `/write`
- `output/` — local landing pages saved here by `/local-page`
- `published/` — move finalized content here
- `rewrites/` — updated content saved here by `/rewrite`

---

## How to Install

1. Clone the base repo: `git clone https://github.com/pageclub/seomachine.git`
2. Copy all files from this zip into the cloned folder — merge, don't replace the whole folder
3. The `.claude/commands/` files become slash commands inside Claude Code automatically
4. Fill out the context files before running any commands (start with `brand-voice.md`)

---

## First Steps After Installing

1. Fill out `context/brand-voice.md`
2. Fill out `context/target-keywords.md` with your services and cities
3. Fill out `context/internal-links-map.md` with your existing pages
4. Paste 2 existing pages into `context/writing-examples.md`
5. Open the folder in Claude Code: `claude-code .`
6. Run your first local page: `/local-page [your service] in [your city]`

---

## Priority Order for Filling Out Context Files

| Priority | File | Time to Fill |
|---|---|---|
| 1 | `brand-voice.md` | 15 min |
| 2 | `target-keywords.md` | 20 min |
| 3 | `internal-links-map.md` | 20 min |
| 4 | `writing-examples.md` | 10 min (paste existing content) |
| 5 | `competitor-analysis.md` | 30 min |
| 6 | `style-guide.md` | 10 min |
