# /local-page

Generate a conversion-optimized local service landing page targeting a specific `[Service] + [City]` combination, with full entity SEO coverage per `context/entity-seo.md`.

## Usage

```
/local-page [service] in [city, state]
```

**Examples:**
```
/local-page drywall repair in Round Rock TX
/local-page TV mounting in Cedar Park TX
/local-page ceiling fan installation in Pflugerville TX
```

---

## What This Command Does

1. Pulls context from `context/entity-seo.md`, `context/seo-guidelines.md`, `context/brand-voice.md`, and `context/internal-links-map.md`
2. Builds a complete entity map for the service/location before writing begins
3. Writes a complete local landing page (1,000–1,500 words) structured for both conversion and local SEO
4. Runs entity density check — flags any checklist items not met before saving
5. Generates schema markup referencing primary entities
6. Saves output to `/output/local-[service]-[city]-[date].md`

---

## Step 1 — Entity Pre-Planning

Before writing any copy, output a filled-out entity map using the template from `context/entity-seo.md`. Populate every bracket with specific terms for the service and location given. Do not use placeholder text — use real, specific entities.

Format:

```
ENTITY MAP: [Service] + [City, State]

🔵 Material Entities: [list specific materials]
🟢 Process Entities: [list specific processes]
🟡 Location Entities: [primary city, neighboring cities, county, ZIP or neighborhood]
🔴 Problem/Solution: [specific problem] → [specific solution]
🟠 Tools: [list specific tools]
🟣 Property Types: [list applicable property types]
⚪ Trade Relationships: [list related trades]
🔷 Outcomes: [list specific outcomes]
🔶 Pricing Signals: [list pricing language to use]
```

Do not begin writing the page until this map is complete.

---

## Step 2 — Page Structure

Generate the page in this exact order:

### H1 — Primary Target
Format: `[Service] in [City], [State] — [Short Value Prop]`
Must contain: primary service entity + primary location entity

### Intro Paragraph (100–150 words)
Must contain within the first 100 words:
- Primary service entity
- Primary city entity
- One problem/solution entity pair
- One Knowledge Graph relationship phrase ("is a" or "located in" structure)

### What's Involved — H2 Section
Core process, sub-processes, and materials used.
Must contain: 2+ process entities, 2+ material entities, 1+ tool entity

### Service Area — H2 Section
Primary city plus surrounding cities and county.
Must contain: 3+ location entities including county name and at least one ZIP or neighborhood reference

### Who This Is For — H2 Section
Property types served and trade relationships.
Must contain: 1+ property type entity, 1+ trade relationship entity

### What You Get — H2 Section
Outcomes and pricing signals.
Must contain: 1+ outcome entity, 1+ pricing/cost entity

### FAQ Section — H2 with 4–5 Q&As
Each answer must contain at least one entity not already in that answer's question.
At least one FAQ answer must include a Knowledge Graph relationship phrase.

### CTA / Closing Paragraph
Reinforce city name, service, and one outcome entity. Include a clear call to action.

### Schema Markup Block
Generate `LocalBusiness` JSON-LD referencing:
- `serviceType` = core process entity
- `areaServed` = array of all location entities
- `description` = sentence containing material + outcome entity
- `offers` = pricing entity if applicable

---

## Step 3 — Entity Density Check

After writing, output this checklist with each item marked pass or fail:

```
ENTITY DENSITY CHECK: [Service] + [City]

[ ] 2+ material entities present
[ ] 2+ process entities present
[ ] 3+ location entities present (city + county + ZIP/neighborhood)
[ ] 1+ problem/solution pair present
[ ] 1+ outcome entity present
[ ] 1+ pricing signal present
[ ] 2+ Knowledge Graph relationship phrases in body copy
[ ] Schema markup includes primary entities
[ ] No single entity phrase repeated more than 3 times

RESULT: PASS / NEEDS REVISION
```

If any item fails, revise the relevant section before saving.

---

## Output

Save completed file to:
```
output/local-[service-slug]-[city-slug]-[YYYY-MM-DD].md
```

File should contain in order:
1. Entity map
2. Entity density checklist result
3. Full page content
4. Schema markup block
