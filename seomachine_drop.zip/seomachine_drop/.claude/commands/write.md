# /write

Create a long-form SEO-optimized article (2,000–3,000+ words) on the given topic.

## Usage

```
/write [topic or research brief]
```

**Examples:**
```
/write how to fix a hole in drywall
/write research/brief-drywall-repair-cost-2025-11-01.md
/write best practices for TV mounting over a fireplace
```

---

## What This Command Does

1. Pulls context from `context/brand-voice.md`, `context/style-guide.md`, `context/seo-guidelines.md`, `context/entity-seo.md`, `context/target-keywords.md`, and `context/internal-links-map.md`
2. Identifies target keyword and entity requirements for the topic
3. Writes a complete article meeting all SEO and entity density requirements
4. Runs post-write checks (entity density, keyword density, structure)
5. Provides meta elements and internal link suggestions
6. Saves to `/drafts/[topic-slug]-[date].md`

---

## Pre-Write Checklist

Before writing, confirm:
- [ ] Target primary keyword identified
- [ ] Search intent classified (informational / commercial / transactional)
- [ ] Entity map drafted for applicable entity types (material, process, problem/solution, outcome minimum)
- [ ] Internal link opportunities identified from `context/internal-links-map.md`

---

## Article Structure

### H1
Contains primary keyword. Written as a benefit-driven headline, not just the keyword phrase.

### Introduction (150–200 words)
- Hook: problem, question, or surprising fact
- Establish relevance to reader
- Preview what they'll learn
- Primary keyword in first 100 words

### Body Sections (H2s)
- One H2 every 300–400 words
- At least 2 H2s contain keyword variations or entity phrases
- Each section answers a specific question or covers a distinct subtopic
- Use H3s for sub-points within sections

### FAQ Section
- 4–6 questions based on "People Also Ask" patterns for the topic
- Each answer 75–150 words
- Include entity phrases naturally in answers

### Conclusion
- Summarize key takeaways (do not just repeat the intro)
- One clear CTA
- Internal link to a relevant service or city page

---

## SEO Requirements

Per `context/seo-guidelines.md`:
- Primary keyword density: 1–2%
- Keyword in H1, first 100 words, 2–3 H2s
- 3–5 internal links with descriptive anchor text
- 2–3 external authority links
- Meta title: 50–60 characters
- Meta description: 150–160 characters

---

## Entity SEO Requirements

Per `context/entity-seo.md`, blog posts must include minimum 4 entity categories:
- Material entities (if applicable)
- Process entities
- Problem/solution entities
- Outcome entities

Run entity density check after writing. Flag any gaps.

---

## Auto-Triggered Agents

After writing, the following agents automatically analyze the content:
- **SEO Optimizer** — on-page SEO recommendations
- **Meta Creator** — meta title and description options
- **Internal Linker** — specific internal linking suggestions
- **Keyword Mapper** — keyword placement and density analysis

---

## Output

Save to: `drafts/[topic-slug]-[YYYY-MM-DD].md`

Include at top of file:
- Target keyword
- Search intent
- Entity map (abbreviated)
- Meta title options (3)
- Meta description options (3)
- Full article
