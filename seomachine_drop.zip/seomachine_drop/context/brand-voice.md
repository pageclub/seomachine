# Brand Voice

Fill this out before running any write or landing page commands. Claude reads this file to match your tone on every piece of content.

---

## Business Overview

- **Business name:** `[Your business name]`
- **Website:** `[yourdomain.com]`
- **Primary service:** `[e.g., handyman installation, drywall repair]`
- **Service area:** `[e.g., Austin TX and surrounding cities]`
- **Target customer:** `[e.g., homeowners in the Austin suburbs, property managers, remodeling contractors]`

---

## Voice Pillars

List 3–4 words that describe how you sound:

- `[e.g., Straightforward]`
- `[e.g., Knowledgeable]`
- `[e.g., Approachable]`
- `[e.g., Local]`

---

## Tone by Content Type

| Content Type | Tone |
|---|---|
| Service/landing pages | `[e.g., Direct, confident, no fluff]` |
| Blog posts | `[e.g., Helpful, educational, conversational]` |
| FAQs | `[e.g., Plain English, no jargon]` |
| CTAs | `[e.g., Action-oriented, low pressure]` |

---

## Core Brand Messages

What do you want every reader to walk away knowing?

1. `[e.g., We specialize in installation — we don't do full renovations]`
2. `[e.g., We charge by the item, not by the hour]`
3. `[e.g., We serve Austin and 14 surrounding cities]`
4. `[e.g., Fast scheduling, clean work, no surprises]`

---

## Writing Style Guidelines

- **Sentence length:** `[e.g., Short to medium — no run-ons]`
- **Paragraph length:** `[e.g., 2–3 sentences max]`
- **Point of view:** `[e.g., We/our — first person plural]`
- **Use of "you":** `[e.g., Yes — address the customer directly]`
- **Contractions:** `[e.g., Yes — we're, you'll, it's]`
- **Oxford comma:** `[e.g., Yes]`

---

## Terminology Preferences

Words and phrases you use (and don't use):

| Use This | Not This |
|---|---|
| `[e.g., installation]` | `[e.g., setup]` |
| `[e.g., we'll handle it]` | `[e.g., our team will facilitate]` |
| `[Your preferred terms]` | `[Terms to avoid]` |

---

## What We Never Say

- `[e.g., "world-class"]`
- `[e.g., "seamless experience"]`
- `[e.g., "passion for excellence"]`
- `[e.g., Any claim we can't back up]`

---

## Differentiators to Weave In

What makes you different from other contractors in your area? Reference these naturally in content:

- `[e.g., Item-based pricing — customers know the cost upfront]`
- `[e.g., Installation-only focus — faster, more specialized]`
- `[e.g., Serving 14 cities across the Austin metro]`
- `[Add your own]`
