# Internal Links Map

Claude uses this file to add internal links to every piece of content. Keep it updated as you publish new pages.

---

## How to Use This File

List every key page on your site with its URL, a short description, and suggested anchor text. Claude will reference this when writing to add relevant internal links.

---

## Service Pages

| Page Title | URL | Description | Suggested Anchor Text |
|---|---|---|---|
| `[e.g., Drywall Repair Austin]` | `[/drywall-repair/austin/]` | `[Main drywall repair service page]` | `[drywall repair in Austin]` |
| `[Add page]` | `[URL]` | `[Description]` | `[Anchor text]` |

---

## City Landing Pages

| Page Title | URL | Primary Service | Suggested Anchor Text |
|---|---|---|---|
| `[e.g., Handyman Austin TX]` | `[/austin/]` | `[General handyman]` | `[handyman services in Austin]` |
| `[Add page]` | `[URL]` | `[Service]` | `[Anchor text]` |

---

## Blog / Resource Pages

| Page Title | URL | Topic | Suggested Anchor Text |
|---|---|---|---|
| `[e.g., How Much Does Drywall Repair Cost?]` | `[/blog/drywall-repair-cost/]` | `[Pricing guide]` | `[drywall repair cost guide]` |
| `[Add page]` | `[URL]` | `[Topic]` | `[Anchor text]` |

---

## Homepage & Core Pages

| Page | URL | Notes |
|---|---|---|
| Homepage | `/` | Link when referencing the business generally |
| About | `/about/` | Link when mentioning the team or background |
| Contact | `/contact/` | Link in CTAs |
| `[Add others]` | `[URL]` | `[Notes]` |

---

## Topic Cluster Map

Use this to understand which pages belong to the same cluster so Claude can link within clusters:

### Cluster: `[e.g., Drywall Services]`
- Pillar: `[/drywall-repair/austin/]`
- Cluster pages: `[/drywall-repair/round-rock/]`, `[/drywall-repair/cedar-park/]`, `[/blog/drywall-repair-cost/]`

### Cluster: `[e.g., TV Mounting]`
- Pillar: `[/tv-mounting/austin/]`
- Cluster pages: `[Add city and blog pages]`

### Cluster: `[Add more clusters as needed]`
