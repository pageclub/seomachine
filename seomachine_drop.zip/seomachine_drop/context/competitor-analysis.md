# Competitor Analysis

Claude uses this file to differentiate your content from competitors and identify gaps to exploit.

---

## Primary Competitors

List your top 3–5 direct competitors in your market:

| Competitor | Website | Notes |
|---|---|---|
| `[Competitor name]` | `[URL]` | `[e.g., strong in Austin, weak in suburbs]` |
| `[Competitor name]` | `[URL]` | `[Notes]` |
| `[Competitor name]` | `[URL]` | `[Notes]` |

---

## Their Content Strategy

What are competitors writing about?

- `[e.g., Most focus on general handyman — not service-specific pages]`
- `[e.g., Few have city-specific landing pages outside Austin proper]`
- `[e.g., Pricing content is vague — no item-based pricing pages]`

---

## Keyword Gaps

Keywords competitors rank for that you don't yet have content for:

| Keyword | Competitor Ranking | Opportunity |
|---|---|---|
| `[keyword]` | `[competitor name]` | `[e.g., Low competition, high local intent]` |
| `[keyword]` | `[competitor name]` | `[notes]` |

---

## Content Gaps

Topics competitors haven't covered well that you can own:

- `[e.g., Item-based pricing explainers — no competitor covers this clearly]`
- `[e.g., Suburb-specific pages for Pflugerville, Thrall, Taylor]`
- `[e.g., "What's included in a TV mounting service" — most competitors skip this]`

---

## Differentiation Angles

What you do that competitors don't — use these in content:

- `[e.g., Installation-only specialization — faster and more focused]`
- `[e.g., Flat item pricing vs. hourly — customers know cost upfront]`
- `[e.g., Serving smaller cities most competitors ignore]`
- `[Add your own]`

---

## Competitor Weaknesses to Exploit

- `[e.g., Most competitor pages are thin — under 500 words]`
- `[e.g., No FAQ sections on service pages]`
- `[e.g., No schema markup on most competitor pages]`
- `[e.g., Generic content not written for local intent]`
