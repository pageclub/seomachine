# Style Guide

Formatting and editorial standards for all content. Claude follows these rules on every piece of writing.

---

## Grammar & Mechanics

- **Tense:** Present tense for service descriptions, past tense for completed work examples
- **Person:** First person plural (we/our) for service copy; second person (you/your) for customer-facing instructions
- **Contractions:** Allowed and encouraged for natural tone
- **Oxford comma:** Required
- **Em dashes:** Use sparingly — only for emphasis or a sharp pivot in thought
- **Exclamation points:** Maximum one per page, only in CTAs

---

## Capitalization

- Service names: lowercase unless part of a proper brand name (`drywall repair`, not `Drywall Repair`)
- City/state: capitalize as proper nouns (`Austin, TX`)
- Job titles: lowercase when used generically (`our technician`, not `our Technician`)
- Headings: sentence case (`How drywall repair works`, not `How Drywall Repair Works`)

---

## Numbers & Formatting

- Spell out numbers one through nine; use numerals for 10 and above
- Always use numerals for: prices, measurements, percentages, addresses
- Use `$` not `dollars` for prices: `$150`, not `150 dollars`
- Measurements: `5/8-inch drywall`, `8-foot ceiling`

---

## Formatting Standards

- **Bold:** Use for key terms on first use, callouts, and checklist items — not for decoration
- **Italics:** Use for emphasis or titles only
- **Bullet lists:** Use for 3+ parallel items; do not use for 1–2 items
- **Numbered lists:** Use only for sequential steps
- **Tables:** Use for comparisons, pricing tiers, or feature lists
- **Block quotes:** Use sparingly for testimonials or key stats

---

## Headers

- H1: One per page, includes primary keyword
- H2: Section headers, keyword variations where natural
- H3: Sub-sections within H2 blocks only
- Do not use H4 or deeper in standard content

---

## Links

- External links: open in new tab, include `rel="noopener"`
- Internal links: descriptive anchor text, never "click here"
- Do not hyperlink entire sentences — link 2–5 word phrases only

---

## Terminology

Consistent terms to use across all content:

| Preferred | Avoid |
|---|---|
| `[Your preferred term]` | `[Term to avoid]` |
| `[Add more]` | `[Add more]` |

---

## What to Avoid

- Filler phrases: "In today's world," "It goes without saying," "At the end of the day"
- Weak openers: "In this article, we will..."
- Vague claims: "high quality," "best in class," "top-notch"
- Passive voice where active is cleaner
- AI-sounding patterns: starting multiple sentences with "Additionally," "Furthermore," "Moreover"
