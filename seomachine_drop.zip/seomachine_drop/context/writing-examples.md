# Writing Examples

Paste 2–3 of your best existing pages or blog posts here. Claude reads these to match your voice and structure on new content.

---

## How to Use This File

Copy the full text of 2–3 pages from your site that best represent how you want to sound. Include the URL for reference. Add a brief note about what makes each example good.

If you don't have existing content yet, paste in 2–3 examples from other sites you want to emulate — and note that they're reference examples, not your own.

---

## Example 1

**URL:** `[https://yoursite.com/page-url/]`
**Why this is a good example:** `[e.g., Strong local tone, clear item pricing, good FAQ section]`

---

`[Paste full page content here]`

---

## Example 2

**URL:** `[https://yoursite.com/page-url/]`
**Why this is a good example:** `[e.g., Good use of process entities, clear outcome language]`

---

`[Paste full page content here]`

---

## Example 3 (optional)

**URL:** `[https://yoursite.com/page-url/]`
**Why this is a good example:** `[Notes]`

---

`[Paste full page content here]`

---

## Notes for Claude

After reading these examples, Claude should note:

- The average paragraph length
- How the business refers to itself (we/I/the team)
- How pricing is mentioned (direct, soft, avoided)
- How CTAs are written
- Any recurring structural patterns (e.g., always ends with a FAQ)
