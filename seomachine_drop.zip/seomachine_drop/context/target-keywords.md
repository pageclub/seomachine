# Target Keywords

Fill this out with your service/city keyword combinations. Claude uses this file during research and writing to target the right keywords for each page.

---

## How to Use This File

Organize keywords by service (pillar), then list city variations and long-tail variations under each. Update this file as you add new services or cities.

---

## Keyword Structure

For each service, list:
- **Primary keyword** — the exact phrase you want to rank for
- **City variations** — one per city you serve
- **Long-tail variations** — question-based, problem-based, or modifier-based phrases
- **Search intent** — informational, navigational, transactional, or commercial

---

## Services & Keywords

### [Service 1 — e.g., Drywall Repair]

**Primary keyword:** `[e.g., drywall repair Austin TX]`

**City variations:**
- `[e.g., drywall repair Round Rock TX]`
- `[e.g., drywall repair Cedar Park TX]`
- `[e.g., drywall repair Pflugerville TX]`
- `[Add more cities]`

**Long-tail variations:**
- `[e.g., how much does drywall repair cost in Austin]`
- `[e.g., water damaged drywall repair near me]`
- `[e.g., drywall patch and texture match Austin]`

**Search intent:** Transactional / Commercial

---

### [Service 2 — e.g., TV Mounting]

**Primary keyword:** `[e.g., TV mounting service Austin TX]`

**City variations:**
- `[Add cities]`

**Long-tail variations:**
- `[Add long-tail phrases]`

**Search intent:** `[Transactional / Commercial / Informational]`

---

### [Service 3]

*(Copy the block above for each additional service)*

---

## City Priority List

List your cities in order of targeting priority:

1. `[Primary city — e.g., Austin TX]`
2. `[e.g., Round Rock TX]`
3. `[e.g., Cedar Park TX]`
4. `[e.g., Pflugerville TX]`
5. `[e.g., Georgetown TX]`
6. `[Add more]`

---

## Keyword Status Tracker

Use this table to track what's been written and what still needs pages:

| Service | City | Page Created? | URL |
|---|---|---|---|
| `[Service]` | `[City]` | Yes / No | `[URL or blank]` |
| | | | |

---

## Negative Keywords / Topics to Avoid

Keywords or topics that are out of scope for your business:

- `[e.g., full home renovation — we don't do this]`
- `[e.g., roofing — out of scope]`
- `[Add your own]`
