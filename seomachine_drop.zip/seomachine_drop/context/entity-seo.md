# Entity SEO Guidelines

This file defines the entity SEO framework for all content produced by SEO Machine. Every page — blog post, service page, or landing page — should meet the entity density checklist before publishing.

---

## What Is Entity SEO?

Entity SEO is the practice of embedding semantically meaningful, real-world concepts (entities) into your content so that Google's Knowledge Graph can understand *what* your page is about — not just *which keywords* it contains.

Entities include: materials, processes, locations, tools, outcomes, people, businesses, and relationships between them. The goal is not keyword stuffing — it is contextual completeness. A page that mentions the right entities in the right relationships signals topical authority to Google.

---

## Entity SEO Page Template

**Page Target:** `[Service] + [Location]`
*(Example: Drywall Repair + Round Rock TX)*

---

### 🔵 Material Entities
What physical materials are involved?

- Primary material: `[e.g., 5/8" drywall, joint compound]`
- Secondary materials: `[e.g., mesh tape, corner bead, primer]`
- Brand/product names: `[e.g., USG SheetRock, ProForm]`

---

### 🟢 Process Entities
What actions/steps are performed?

- Core process: `[e.g., patching, taping, mudding]`
- Sub-processes: `[e.g., sanding, skim coating, texturing]`
- Outcome process: `[e.g., level 5 finish, smooth wall prep]`

---

### 🟡 Location Entities
Where does this service exist?

- Primary city: `[e.g., Austin TX]`
- Service area cities: `[e.g., Round Rock, Cedar Park, Pflugerville]`
- County/Region: `[e.g., Travis County, Williamson County]`
- Neighborhood/ZIP: `[e.g., 78681, North Austin]`

---

### 🔴 Problem / Solution Entities
What pain points does this solve?

- Problem: `[e.g., water-damaged drywall, nail pops, wall cracks]`
- Cause: `[e.g., moisture, settling, impact damage]`
- Solution: `[e.g., patch and refinish, full sheet replacement]`

---

### 🟠 Tool / Equipment Entities
What tools are used?

- `[e.g., drywall saw, screw gun, mud pan, corner bead tool]`

---

### 🟣 Property Type Entities
What property context applies?

- `[e.g., residential home, commercial office, new construction, remodel]`

---

### ⚪ Trade Relationship Entities
Who else is involved or associated?

- `[e.g., general contractor, painter, framer, home inspector]`

---

### 🔷 Outcome Entities
What is the end result?

- `[e.g., smooth finish, fire-rated wall, soundproof partition]`

---

### 🔶 Cost / Pricing Entities
What pricing signals should appear?

- `[e.g., per sq ft rate, free estimate, flat rate repair]`

---

## Knowledge Graph Relationship Phrases

Include these relationship structures naturally in body copy. Do not list them — weave them into sentences.

| Relationship | Example Phrase Structure |
|---|---|
| Is a | `"[Service] is a [category]"` |
| Part of | `"[Material] is part of [process]"` |
| Used for | `"[Product] used for [application]"` |
| Located in | `"Serving [city], located in [county/region]"` |
| Associated with | `"[Trade] works alongside [related trade]"` |

---

## Entity Density Checklist

Before publishing any page, confirm the content includes:

- [ ] 2+ material entities
- [ ] 2+ process entities
- [ ] 3+ location entities (city, county, ZIP or neighborhood)
- [ ] 1+ problem/solution pair
- [ ] 1+ outcome entity
- [ ] 1+ pricing signal
- [ ] 2+ Knowledge Graph relationship phrases in body copy
- [ ] Schema markup referencing primary entities

---

## Entity Density Rules

- Target **5–6 entity types** woven into every page
- Entities should appear in: H1, H2s, body paragraphs, FAQ section, and schema markup
- Never list entities mechanically — they must appear in natural, readable sentences
- Do not repeat the same entity phrase more than 2–3 times (this is stuffing, not density)
- Entity coverage should be distributed throughout the page, not front-loaded

---

## Application by Content Type

### Service/Landing Pages
All 9 entity categories above are required. Location entities are especially critical — include primary city, at least one neighboring city, and one county reference minimum.

### Blog Posts
Material, process, problem/solution, and outcome entities are required. Location entities are optional unless the post is geo-targeted.

### FAQ Sections
Each FAQ answer should contain at least one entity from a different category than the question itself. This expands topical coverage without adding page length.

---

## Schema Markup Requirements

Every local service page must include schema that explicitly references primary entities:

- `LocalBusiness` or `HomeAndConstructionBusiness` type
- `ServiceType` matching the core process entity
- `areaServed` matching location entities (city + county minimum)
- `description` containing at least one material entity and one outcome entity
- `makesOffer` referencing pricing entities where applicable
