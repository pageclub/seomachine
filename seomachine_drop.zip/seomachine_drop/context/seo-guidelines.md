# SEO Guidelines

These guidelines apply to all content produced by SEO Machine — blog posts, service pages, and landing pages. Every piece of content must meet all applicable standards before publishing.

---

## Content Length Requirements

| Content Type | Minimum | Target |
|---|---|---|
| Blog post | 2,000 words | 2,500–3,000+ words |
| Local service/landing page | 800 words | 1,000–1,500 words |
| FAQ page | 600 words | 800–1,200 words |

---

## Keyword Optimization Rules

- **Primary keyword density:** 1–2% (do not exceed)
- Primary keyword must appear in: H1, first 100 words, 2–3 H2 headings, meta title, meta description
- Use semantic variations and LSI keywords throughout — avoid repeating the exact primary keyword phrase
- Do not force keywords into sentences where they read unnaturally
- Check for keyword stuffing risk using `keyword_analyzer.py` before publishing

---

## Entity SEO Requirements

**Every page must pass the Entity Density Checklist defined in `context/entity-seo.md`.**

Entity SEO is not optional — it is a core ranking signal for local and topical authority. Specifically:

- All local service pages require all 9 entity categories from the entity template
- Blog posts require minimum 4 entity categories (material, process, problem/solution, outcome)
- Entity coverage must be distributed throughout the page — not front-loaded
- Schema markup must reference primary entities explicitly (see schema section below)

Run the entity pre-planning step before writing any local page. Do not skip it.

---

## Meta Element Standards

**Meta Title:**
- 50–60 characters
- Include primary keyword and location (for local pages)
- Do not truncate mid-word

**Meta Description:**
- 150–160 characters
- Include primary keyword, a benefit or outcome entity, and a soft CTA
- Write for clicks, not just crawlers

---

## Heading Structure

- One H1 per page — must contain primary keyword + location (for local pages)
- H2s every 300–400 words
- H3s for sub-sections within H2 blocks
- Never skip heading levels (H1 → H3 with no H2 is invalid)
- At least 2 H2s should contain keyword variations or entity phrases

---

## Internal Linking

- 3–5 internal links per page minimum
- Use descriptive anchor text — never "click here" or "read more"
- Link to pillar pages, related service pages, and cluster content
- Reference `context/internal-links-map.md` for available pages and recommended anchor text
- Do not link to the same page twice in one article with identical anchor text

---

## External Linking

- 2–3 external authority links per blog post
- Link to .gov, .edu, industry associations, or well-known publications
- Open in new tab
- Do not link to competitors

---

## Readability Requirements

- Reading level: 8th–10th grade (Flesch-Kincaid)
- Average sentence length: 15–20 words
- Paragraphs: 2–4 sentences
- Use subheadings, bullets, and numbered lists to break up dense content
- Passive voice ratio: under 15%

---

## Schema Markup Requirements

All local service pages require JSON-LD schema. Minimum required types:

- `LocalBusiness` (or subtype: `HomeAndConstructionBusiness`, `Plumber`, `GeneralContractor`, etc.)
- `Service` nested within or linked via `makesOffer`
- `areaServed` — array of all location entities (city, county, ZIPs)
- `description` — must contain at least one material entity and one outcome entity
- `address` — full address with `PostalAddress` type

Optional but recommended:
- `FAQPage` schema for FAQ sections
- `Review` / `AggregateRating` if reviews exist
- `Offer` with `priceCurrency` and pricing entity language

---

## URL Structure

- Lowercase only
- Hyphens between words, no underscores
- Local pages: `/[service-slug]/[city-slug]/`
- Blog posts: `/blog/[topic-slug]/`
- Keep URLs short — remove filler words (a, the, and, in) where possible without losing meaning

---

## Image Optimization

- Descriptive file names with keywords: `drywall-repair-round-rock-tx.jpg`
- Alt text: describe the image content and include a relevant entity where natural
- Compress images before upload (under 200kb preferred)
- Include at least one image per 600 words

---

## Pre-Publish Checklist

Before marking any content as ready:

- [ ] Word count meets minimum for content type
- [ ] Primary keyword in H1, first 100 words, 2+ H2s
- [ ] Keyword density 1–2% (verified)
- [ ] Entity density checklist passed (see `context/entity-seo.md`)
- [ ] Meta title 50–60 characters
- [ ] Meta description 150–160 characters
- [ ] 3–5 internal links with descriptive anchor text
- [ ] Schema markup present and entity-referenced
- [ ] Readability score acceptable
- [ ] No keyword stuffing warnings
- [ ] Brand voice consistent with `context/brand-voice.md`
